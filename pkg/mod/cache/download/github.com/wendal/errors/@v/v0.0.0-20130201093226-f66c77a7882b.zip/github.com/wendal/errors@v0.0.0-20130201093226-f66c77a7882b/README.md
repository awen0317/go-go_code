errors
======

增强型errors包(for golang)
--------------------------

完全兼容官方的errors包,且附带堆栈信息,方便debug
----------------------------------------------

API完全兼容

安装
----

```
go get github.com/wendal/errors
```

使用
----

仅需将
```
import errors
```

改为
```
import github.com/wendal/errors
```

