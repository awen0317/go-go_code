package etcd

const version = "v2"
